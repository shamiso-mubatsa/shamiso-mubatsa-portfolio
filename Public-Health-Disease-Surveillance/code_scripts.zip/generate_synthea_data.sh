#!/bin/bash
cd ~/synthea

# Generate for each hospital
java -jar synthea-with-dependencies.jar -p 20 Michigan "Calumet" --config covid19
java -jar synthea-with-dependencies.jar -p 36 Michigan "Houghton" --config covid19
java -jar synthea-with-dependencies.jar -p 210 Michigan "Baraga" --config covid19
java -jar synthea-with-dependencies.jar -p 1200 Michigan "Marquette" --config covid19
