#!/bin/bash
# Configure Static IP for VM (example IP for Aspirus)
nmcli con mod "Wired connection 1" ipv4.addresses 192.168.17.114/24
nmcli con mod "Wired connection 1" ipv4.gateway 192.168.17.1
nmcli con mod "Wired connection 1" ipv4.method manual
nmcli con up "Wired connection 1"

# Ping other hospital VMs
for ip in 192.168.17.115 192.168.17.116 192.168.17.117 192.168.17.118; do
  echo "Pinging $ip..."
  ping -c 2 $ip
done
