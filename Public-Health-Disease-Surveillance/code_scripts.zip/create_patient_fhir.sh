#!/bin/bash
curl -X POST http://localhost:8090/fhir/Patient \
  -H "Content-Type: application/fhir+json" \
  -d @patient.json
