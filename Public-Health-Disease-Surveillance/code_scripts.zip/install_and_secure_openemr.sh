#!/bin/bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install LAMP stack
sudo apt install apache2 mysql-server php libapache2-mod-php php-mysql -y

# Download OpenEMR
wget https://sourceforge.net/projects/openemr/files/latest/download -O openemr.tar.gz
tar -xvzf openemr.tar.gz
sudo mv openemr* /var/www/html/openemr
sudo chown -R www-data:www-data /var/www/html/openemr

# Enable firewall and rules
sudo apt install ufw
sudo ufw allow http
sudo ufw allow https
sudo ufw allow ssh
sudo ufw enable

# Apache security
sudo a2enmod rewrite
sudo a2enconf security
sudo systemctl restart apache2
