#!/bin/bash
sudo docker pull hapiproject/hapi:latest
mkdir -p ~/fhirConfig
cd ~/fhirConfig
wget https://raw.githubusercontent.com/hapifhir/hapi-fhir-jpaserver-starter/master/src/main/resources/application.yaml

docker run --name hapifhir -p 8090:8080 -itd \
  -v ~/fhirConfig:/configs \
  -e "-spring.config.location=file:///configs/application.yaml" \
  hapiproject/hapi:latest

docker logs hapifhir
